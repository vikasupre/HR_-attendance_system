from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
import random



# Create your models here.
class User(AbstractUser):
    email = models.EmailField(_('email address'), unique=True)
    emp_id = models.CharField(max_length=70, default='emp'+str(random.randrange(100,999,1)))

class Attendance(models.Model):
    STATUS = (('PRESENT', 'PRESENT'), ('ABSENT', 'ABSENT'))
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    check_in = models.TimeField()
    check_out = models.TimeField(null=True,blank=True)
    status = models.CharField(choices=STATUS, max_length=15 )
    
    class Meta:
        ordering =('-date','-check_in')





