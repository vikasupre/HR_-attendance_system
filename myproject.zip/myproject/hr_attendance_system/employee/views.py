from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import Employee_RegistrationForm,LoginForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .models import Attendance
from django.contrib import messages
from django.core.paginator import Paginator
from datetime import datetime
from django.utils import timezone



# Create your views here.
@login_required(redirect_field_name='signin')
def index(request):
    return render(request,'add_attendance.html')

def signup(request):
    if request.method=='POST':
        fm=Employee_RegistrationForm(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(
                request, 'Congratulations! You have registered successfully')
            return redirect('/signin')
    else:
        fm=Employee_RegistrationForm()
    return render(request,'signup.html',{'form':fm})


def signin(request):
    fm = LoginForm()
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = LoginForm(request=request, data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)
                    return redirect('/add_attendance')
        else:
            return render(request, 'signin.html', {'form': fm})
    else:
        return render(request, 'add_attendance.html', {'form': fm})

def signout(request):
    logout(request)
    return redirect('/signin')

@login_required

def add_attendance(request):
    return render(request,'add_attendance.html')
@login_required
def checkintime(request):
    user = request.user  # current user
    check_in=datetime.now().time()
    atten=Attendance(user=user,check_in=check_in)
    atten.save()
    return render(request,'add_attendance.html')

@login_required
def checkouttime(request):
    atten= Attendance.objects.filter(check_out=None)[0]
    atten.check_out= datetime.now().time()
    if atten.check_in and atten.check_out:
        atten.status='PRESENT'
    else:
        atten.status='ABSENT'
    atten.save()
    return render(request,'add_attendance.html')


@login_required
def view_attendance(request):
    atten_list = Attendance.objects.filter(user=request.user)
    paginator=Paginator(atten_list,5)
    page_number=request.GET.get('page')
    atten_list=paginator.get_page(page_number)
    return render(request,'view_attendance.html',{'atten_list':atten_list})





