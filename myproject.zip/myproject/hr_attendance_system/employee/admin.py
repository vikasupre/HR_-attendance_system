from django.contrib import admin
from .models import User,Attendance

# Register your models here.
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display=['emp_id','username','email']
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display=['user','date','check_in','check_out','status']
